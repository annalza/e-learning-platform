from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import boto3

app = Flask(__name__)
CORS(app)

# AWS Comprehend Client (DO NOT hardcode credentials in production!)
comprehend = boto3.client("comprehend", region_name="us-east-1")

expected_keywords = {
    1: {"keywords": {"machine learning", "training data", "algorithms"}, "feedback": "Focus on ML fundamentals."},
    2: {"keywords": {"neural networks", "deep learning", "weights"}, "feedback": "Mention how NN learn."},
    3: {"keywords": {"overfitting", "training data", "regularization"}, "feedback": "Explain how to avoid overfitting."},
    4: {"keywords": {"reinforcement learning", "reward function", "agent"}, "feedback": "Cover RL concepts."},
    5: {"keywords": {"big data", "large-scale", "data processing"}, "feedback": "Mention tools like Hadoop and Spark."}
}

def extract_key_phrases(text):
    response = comprehend.detect_key_phrases(Text=text, LanguageCode="en")
    return {phrase["Text"].lower() for phrase in response["KeyPhrases"]}

def evaluate_answer(question_id, user_answer):
    extracted_keywords = extract_key_phrases(user_answer)
    expected = expected_keywords.get(question_id, {"keywords": set(), "feedback": "No feedback available."})

    matched_keywords = extracted_keywords & expected["keywords"]
    score_percentage = (len(matched_keywords) / len(expected["keywords"])) * 100 if expected["keywords"] else 0

    return {
        "user_answer": user_answer,
        "extracted_keywords": list(extracted_keywords),
        "matched_keywords": list(matched_keywords),
        "score": round(score_percentage, 2),
        "feedback": expected["feedback"]
    }

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/process_answers", methods=["POST"])
def process_answers():
    data = request.json
    answers = data.get("answers", {})

    if not answers:
        return jsonify({"error": "No answers provided"}), 400

    results = [evaluate_answer(int(q_id), ans) for q_id, ans in answers.items()]
    total_score = sum(res["score"] for res in results) / len(results)  # Fix: Average score calculation

    return jsonify({"results": results, "total_score": round(total_score, 2)})  # Round for cleaner output

@app.route("/result")
def result():
    return render_template("result.html")

if __name__ == "__main__":
    app.run(debug=True, port=1234)
