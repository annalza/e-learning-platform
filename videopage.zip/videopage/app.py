from flask import Flask, render_template
import requests
import json


app = Flask(__name__)

# API Gateway URL
API_URL = "https://uodfsbmem2.execute-api.us-east-1.amazonaws.com/stage-elearn"

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/videos")
def videos():
    try:
        response = requests.get(API_URL)
        data = response.json()
        videos = json.loads(data['body'])  # Parse the 'body' field as JSON
        video_urls = [video['url'] for video in videos]  # Extract video URLs

    except Exception as e:
        video_urls = []
        print("Error fetching videos:", e)

    return render_template("videos.html", videos=video_urls)


# Load quiz data
def load_quiz():
    with open("quiz_data.json", "r") as file:
        return json.load(file)

@app.route("/quiz")
def quiz():
    quiz_data = load_quiz()
    return render_template("quiz.html", quiz=quiz_data["quiz"])

if __name__ == "__main__":
    app.run(debug=True)

if __name__ == "__main__":
    app.run(debug=True)
