import boto3

# AWS Comprehend Client Setup
comprehend = boto3.client(
    "comprehend",
    region_name="us-east-1",  # Change to your AWS region
    aws_access_key_id="AKIATEHMKEEYBEFUPCFP",       # Replace with your actual access key
    aws_secret_access_key="R4SMA3f2+nFQDd+2Q4+kVbDFUqplwJieTcDlkfeM"    # Replace with your actual secret key
)
def analyze_sentiment(text):
    response = comprehend.detect_sentiment(Text=text, LanguageCode="en")
    return response["Sentiment"], response["SentimentScore"]

# Example: Analyzing a user's quiz answer
user_answer = "I think the answer is correct, but I'm not sure."
sentiment, score = analyze_sentiment(user_answer)
print(f"Sentiment: {sentiment}")
print(f"Score: {score}")

# Function to extract key phrases
def extract_key_phrases(text):
    response = comprehend.detect_key_phrases(Text=text, LanguageCode="en")
    return [phrase["Text"] for phrase in response["KeyPhrases"]]

# Example: Extracting key phrases from an answer
key_phrases = extract_key_phrases(user_answer)
print(f"Key Phrases: {key_phrases}")