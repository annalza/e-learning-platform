from fastapi import FastAPI, HTTPException
import pyodbc
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Enable CORS (Allow frontend to communicate with backend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow requests from any frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Azure SQL Database Connection
server = "elearning-server-123.database.windows.net"
database = "elearning_db"
username = "dbadmin"
password = "Ammu@2005"

conn_str = f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={server};DATABASE={database};UID={username};PWD={password}"

@app.post("/register")
async def register_user(data: dict):
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        
        # Insert user into the database
        cursor.execute("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)", 
                       (data["username"], data["email"], data["password"]))
        conn.commit()
        
        # Close connection
        cursor.close()
        conn.close()
        
        return {"status": "success", "message": "User registered successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/login")
async def login_user(data: dict):
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()

        # Fetch user from database
        cursor.execute("SELECT * FROM users WHERE email = ? AND password_hash = ?", 
                       (data["email"], data["password"]))
        user = cursor.fetchone()

        # Close connection
        cursor.close()
        conn.close()

        if user:
            return {"status": "success", "message": "Login successful"}
        else:
            raise HTTPException(status_code=401, detail="Invalid credentials")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Run FastAPI app
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
